<script src="/web-app/js/jquery-2.0.3.min.js"></script>
<!--<script src="http://code.jquery.com/jquery-1.9.1.js"></script>-->
<script src="/web-app/js/elvolcan.js"></script>
<div class="content-column"><img src="web-app/img/candelabro.png"></div>
<section class="content-body">
	<div class="bullets first"></div>
	<div class="bullets second"></div>
	<center>
		<div class="success" id="success">

			<p>El mensaje se envió correctamente</p>
		
			<input type="button" id="successButton" value="Ir a la página principal" onclick="javascript:location.href='index.php'">
		
		</div>
	</center>
</section>