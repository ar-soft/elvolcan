<div class="content-column"><center><p style="color:white">"El mejor confort con vista al paraíso lo encontrás en nuestras habitaciones"</p>
	<p style="color:#707173">Todas nuestras Suites cuentan con una excelente vista al lago ya que han sido construidas acompañando la pendiente del lugar. 
		Las terrazas contiguas a las suites le permitirán disfrutar de la naturaleza a pleno.</p><p style="color:white">Las Suites tienen las siguientes comodidades:</p>
		<p style="color:#707173">TV y LCD<br>
			DirectTV<br>
			Teléfono<br>
			Conexión a internet<br>
			Baño con jacuzzi doble, ventanal y techo.<br>
			Caja de seguridad<br>
			Frigobar
			</p></center><img src="web-app/img/candelabro.png"></div>
<section class="content-body">
	<div class="bullets first"></div>
	<div class="bullets second"></div>
	<center>
		<img class="light" src="web-app/img/luz.png">
		<div id="rectangle">
			<div id="orange-rectangle">
				<table>
					<tbody>
						<tr class="first">
							<th>CONFIGURACIÓN</th>
							<th>HABITACIONES</th>
							<th>TARIFAS</th>
						</tr>
						<tr>
							<td>Doble</td>
							<td>(estándar)</td>
							<td>$ 400.-</td>
						</tr>
						<tr>
							<td>Triple</td>
							<td>(estándar)</td>
							<td>$ 450.-</td>
						</tr>
						<tr>
							<td>Cuádruple</td>
							<td>(estándar)</td>
							<td>$ 520.-</td>
						</tr>
						<tr>
							<td>Doble</td>
							<td>(suite)</td>
							<td>$ 800.-</td>
						</tr>
						<tr>
							<td>Cuádruple</td>
							<td>(suite)</td>
							<td>$ 870.-</td>
						</tr>
					</tbody>
				</table>
				<img src="web-app/img/banco.png" class="bank">
			</div>
		</div>
	</center>
</section>