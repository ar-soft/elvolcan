<div class="content-column"><img src="web-app/img/candelabro.png"></div>
<section class="content-body">
	<div class="bullets first"></div>
	<div class="bullets second"></div>
	<center>
		<img class="light" src="web-app/img/luz.png">
		<div id="rectangle">
			<div id="orange-rectangle">
				<table>
					<tbody>
						<tr class="first">
							<th>CONFIGURACIÓN</th>
							<th>HABITACIONES</th>
							<th>TARIFAS</th>
						</tr>
						<tr>
							<td>Doble</td>
							<td>(estándar)</td>
							<td>$ 400.-</td>
						</tr>
						<tr>
							<td>Triple</td>
							<td>(estándar)</td>
							<td>$ 400.-</td>
						</tr>
						<tr>
							<td>Cuádruple</td>
							<td>(estándar)</td>
							<td>$ 400.-</td>
						</tr>
						<tr>
							<td>Doble</td>
							<td>(casco)</td>
							<td>$ 400.-</td>
						</tr>
						<tr>
							<td>Cuádruple</td>
							<td>(casco)</td>
							<td>$ 400.-</td>
						</tr>
					</tbody>
				</table>
				<img src="web-app/img/banco.png" class="bank">
			</div>
		</div>
	</center>
</section>