<div class="content-column"></div>
<section class="content-body">
	<div class="bullets first"></div>
	<div class="bullets second"></div>
	<div><img src="web-app/img/luz.png" id="light"></div>
	<div id="rectangle">
		<div id="orange-rectangle">
			<center>
			<table>
				<tbody>
					<tr class="first">
						<th>HABITACIONES</th>
						<th>CONFIGURACIÓN</th>
						<th>TARIFAS</th>
					</tr>
					<tr>
						<td>Doble</td>
						<td>(estándar)</td>
						<td>$ 400.-</td>
					</tr>
					<tr>
						<td>Triple</td>
						<td>(estándar)</td>
						<td>$ 400.-</td>
					</tr>
					<tr>
						<td>Cuádruple</td>
						<td>(estándar)</td>
						<td>$ 400.-</td>
					</tr>
					<tr>
						<td>Doble</td>
						<td>(casco)</td>
						<td>$ 400.-</td>
					</tr>
					<tr>
						<td>Cuádruple</td>
						<td>(casco)</td>
						<td>$ 400.-</td>
					</tr>
				</tbody>
			</table>
			</center>
			<div><img src="web-app/img/banco.png" id="bank"></div>
		</div>
	</div>
</section>