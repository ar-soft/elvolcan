<footer>
	<img class="logoinferior" src="web-app/img/logoinferior.png">
	<div class="contact-link">
		<a href="?axn=contacto">contacto</a>
	</div>
	<div class="copyright">
		<p>&copy; El Volcán Hotel Serrano - El Volcán, San Luis, Argentina. Todos los derechos reservados</p>
	</div>
</footer>