<footer>
	<div id="information">
		<p>El Hotel posee X habitaciones con todo lo necesario para brindarle el servicio que Ud. se merece.<br>Se encuentra ubicado a YY Km. de San Luis, en una zona atractiva y placentera por sus...</p>
		<h1>San Miguel Arcangel 1163/ El Volcán, San Luis, Argentina <br>Tel: 4494043</h1>
	</div>
	<div class="contact-link">
		<a href="?axn=contacto">contacto</a>
	</div>
</footer>