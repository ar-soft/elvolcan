<script src="/web-app/js/jquery-2.0.3.min.js"></script>
<!--<script src="http://code.jquery.com/jquery-1.9.1.js"></script>-->
<script src="/web-app/js/elvolcan.js"></script>
<div class="content-column"><center><p style="color:white">"El mejor confort con vista al paraíso lo encontrás en nuestras habitaciones"</p>
	<p style="color:#707173">Todas nuestras Suites cuentan con una excelente vista al lago ya que han sido construidas acompañando la pendiente del lugar. 
		Las terrazas contiguas a las suites le permitirán disfrutar de la naturaleza a pleno.</p><p style="color:white">Las Suites tienen las siguientes comodidades:</p>
		<p style="color:#707173">TV y LCD<br>
			DirectTV<br>
			Teléfono<br>
			Conexión a internet<br>
			Baño con jacuzzi doble, ventanal y techo.<br>
			Caja de seguridad<br>
			Frigobar
			</p></center><img src="web-app/img/candelabro.png"></div>
<section class="content-body">
	<div class="bullets first"></div>
	<div class="bullets second"></div>
	<center><img class="light" src="web-app/img/luz.png">

		<div class="image">
		   <div>
			<img id="1" src="/web-app/img/gallery/piscina.jpg" style="display:none"/>
		   </div>
		   <div>
			<img id="2" src="/web-app/img/gallery/entrada.jpg" style="display:none"/>
		   </div>
		</div>


		<div class="arrow-left-div">
			<img src="/web-app/assets/flecha-izq.png" onclick="changeImage('left')" class="flecha-izq" style="display:none"/>
		</div>
		<img src="/web-app/img/recuadro.png" id="square">
		<div class="image-square">
			<img src="" id=""/>
		</div>
		<div class="arrow-right-div">
			<img src="/web-app/assets/flecha-der.png" onclick="changeImage('right')" class="flecha-der" style="display:block"/>
		</div>
	</center>
</section>