<div class="content-column"></div>
<section class="content-body">
	<iframe frameborder="0" scrolling="no" src="src/view/mapa.html">
	</iframe>
</section>