<div class="content-column"><img src="web-app/img/candelabro.png"></div>
<section class="content-body">
	<iframe frameborder="0" scrolling="no" src="src/view/mapa.html">
	</iframe>
</section>